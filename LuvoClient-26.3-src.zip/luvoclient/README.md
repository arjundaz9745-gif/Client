# Luvo Client

Modern **client-side only** Fabric utility mod for **Minecraft 26.3**.

Inspired by Feather Remake / Lunar-style clients.

---

## Features

### HUD Modules
- FPS
- CPS (left | right)
- Coordinates + Direction
- Speed
- Ping
- Memory
- Clock
- Armor status

### Render
- Fullbright
- Zoom (hold `C`)
- Freelook (hold Left Alt)
- Motion Blur toggle
- Logo indicator next to your name in tab list

### UI & Misc
- Modern ClickGUI (Right Shift) with dark/blurred style
- Config: `.minecraft/config/luvoclient.json`
- Lag Fix foundation
- Fully client-side

---

## How to Build (especially from Phone)

### Method 1: GitHub Actions (Recommended – works on mobile)

1. Create a free GitHub account.
2. Create a **new repository** (name it e.g. `LuvoClient`).
3. Upload **all files** from this project into the repository (you can use the GitHub mobile app or website).
4. Make sure the file `.github/workflows/build.yml` is present.
5. Go to the **Actions** tab → click **Build Luvo Client** → **Run workflow**.
6. Wait 2–4 minutes.
7. When finished, open the run → download the artifact **LuvoClient-26.3**.
8. Inside you will find `luvoclient-1.0.0.jar`.

Put that jar in your Minecraft `mods` folder together with Fabric API for 26.3.

### Method 2: On a computer

```bash
./gradlew build
```

Jar will be in `build/libs/`.

---

## Default Keybinds
| Key          | Action             |
|--------------|--------------------|
| Right Shift  | Open Luvo Menu     |
| C            | Zoom (hold)        |
| Left Alt     | Freelook (hold)    |

---

## Credits
Logo provided by the owner.  
Built with Fabric for Minecraft 26.3.
