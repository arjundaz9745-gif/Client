package com.luzero.luvoclient.mixin;

import com.luzero.luvoclient.module.impl.CpsModule;
import com.luzero.luvoclient.LuvoClient;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class MinecraftClientMixin {

    @Inject(method = "startAttack", at = @At("HEAD"))
    private void onLeftClick(CallbackInfo ci) {
        if (LuvoClient.MODULES != null) {
            var cps = LuvoClient.MODULES.getById("cps");
            if (cps instanceof CpsModule module) {
                module.onLeftClick();
            }
        }
    }

    // Right click can be hooked similarly if needed
}
