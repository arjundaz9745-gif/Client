package com.luzero.luvoclient.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public abstract class Module {
    public final String id;
    public final String name;
    public final String description;
    public final Category category;

    public Module(String id, String name, String description, Category category) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public boolean isEnabled() {
        return com.luzero.luvoclient.LuvoClient.CONFIG.isModuleEnabled(id);
    }

    public void setEnabled(boolean enabled) {
        com.luzero.luvoclient.LuvoClient.CONFIG.setModuleEnabled(id, enabled);
        if (enabled) onEnable();
        else onDisable();
    }

    public void toggle() {
        setEnabled(!isEnabled());
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick(Minecraft client) {}
    public void onHudRender(GuiGraphics graphics, float tickDelta) {}

    public enum Category {
        HUD("HUD"),
        RENDER("Render"),
        PLAYER("Player"),
        MISC("Misc");

        public final String displayName;
        Category(String displayName) {
            this.displayName = displayName;
        }
    }
}
