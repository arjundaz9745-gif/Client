package com.luzero.luvoclient.module.impl;

import com.luzero.luvoclient.LuvoClient;
import com.luzero.luvoclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;

public class CoordsModule extends Module {
    public CoordsModule() {
        super("coords", "Coordinates", "Shows player coordinates and direction", Category.HUD);
    }

    @Override
    public void onHudRender(GuiGraphics graphics, float tickDelta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        float[] pos = LuvoClient.CONFIG.getModulePos(id, 4, 28);
        int x = (int) pos[0];
        int y = (int) pos[1];

        BlockPos p = mc.player.blockPosition();
        String dir = mc.player.getDirection().getName().toUpperCase().substring(0, 1);
        String text = String.format("XYZ: %d %d %d  %s", p.getX(), p.getY(), p.getZ(), dir);
        graphics.drawString(mc.font, text, x, y, 0xFFFFFFAA, true);
    }
}
