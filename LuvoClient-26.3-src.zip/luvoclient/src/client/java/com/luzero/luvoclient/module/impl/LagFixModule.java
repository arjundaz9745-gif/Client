package com.luzero.luvoclient.module.impl;

import com.luzero.luvoclient.LuvoClient;
import com.luzero.luvoclient.module.Module;
import net.minecraft.client.Minecraft;

/**
 * Simple client-side lag reduction helpers.
 * Real heavy optimisations come from Sodium / Lithium / Iris etc.
 * This module enables a few safe toggles.
 */
public class LagFixModule extends Module {
    public LagFixModule() {
        super("lagfix", "Lag Fix", "Basic client-side performance helpers", Category.MISC);
    }

    @Override
    public void onEnable() {
        LuvoClient.CONFIG.lagFix = true;
        LuvoClient.CONFIG.save();
    }

    @Override
    public void onDisable() {
        LuvoClient.CONFIG.lagFix = false;
        LuvoClient.CONFIG.save();
    }

    @Override
    public void onTick(Minecraft client) {
        // Placeholder for future safe optimisations
        // e.g. reduce particle density, disable some expensive renders when lagFix is on
    }
}
