package com.luzero.luvoclient.module.impl;

import com.luzero.luvoclient.LuvoClient;
import com.luzero.luvoclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class ClockModule extends Module {
    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("HH:mm:ss");

    public ClockModule() {
        super("clock", "Clock", "Shows real-world time", Category.HUD);
    }

    @Override
    public void onHudRender(GuiGraphics graphics, float tickDelta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        float[] pos = LuvoClient.CONFIG.getModulePos(id, 4, 76);
        int x = (int) pos[0];
        int y = (int) pos[1];

        String text = LocalTime.now().format(FORMAT);
        graphics.drawString(mc.font, text, x, y, 0xFFDDDDFF, true);
    }
}
