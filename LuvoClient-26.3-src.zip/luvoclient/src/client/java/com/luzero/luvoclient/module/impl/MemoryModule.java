package com.luzero.luvoclient.module.impl;

import com.luzero.luvoclient.LuvoClient;
import com.luzero.luvoclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public class MemoryModule extends Module {
    public MemoryModule() {
        super("memory", "Memory", "Shows used / max memory", Category.HUD);
    }

    @Override
    public void onHudRender(GuiGraphics graphics, float tickDelta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        float[] pos = LuvoClient.CONFIG.getModulePos(id, 4, 64);
        int x = (int) pos[0];
        int y = (int) pos[1];

        Runtime rt = Runtime.getRuntime();
        long used = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024);
        long max = rt.maxMemory() / (1024 * 1024);

        String text = "Mem: " + used + " / " + max + " MB";
        graphics.drawString(mc.font, text, x, y, 0xFFAAAAAA, true);
    }
}
