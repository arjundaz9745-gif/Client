package com.luzero.luvoclient.keybind;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public class Keybinds {
    public static KeyMapping OPEN_MENU;
    public static KeyMapping ZOOM;
    public static KeyMapping FREELOOK;

    public static void register() {
        OPEN_MENU = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.luvoclient.open_menu",
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.luvoclient"
        ));

        ZOOM = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.luvoclient.zoom",
                GLFW.GLFW_KEY_C,
                "category.luvoclient"
        ));

        FREELOOK = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.luvoclient.freelook",
                GLFW.GLFW_KEY_LEFT_ALT,
                "category.luvoclient"
        ));
    }
}
