package com.luzero.luvoclient.module.impl;

import com.luzero.luvoclient.keybind.Keybinds;
import com.luzero.luvoclient.module.Module;
import net.minecraft.client.Minecraft;

public class FreelookModule extends Module {
    public static boolean active = false;
    public static float cameraYaw;
    public static float cameraPitch;

    public FreelookModule() {
        super("freelook", "Freelook", "Freely look around without moving player (Lunar style)", Category.RENDER);
    }

    @Override
    public void onTick(Minecraft client) {
        if (!isEnabled() || client.player == null) {
            active = false;
            return;
        }

        boolean keyDown = Keybinds.FREELOOK.isDown();
        if (keyDown && !active) {
            active = true;
            cameraYaw = client.player.getYRot();
            cameraPitch = client.player.getXRot();
        } else if (!keyDown) {
            active = false;
        }
    }
}
