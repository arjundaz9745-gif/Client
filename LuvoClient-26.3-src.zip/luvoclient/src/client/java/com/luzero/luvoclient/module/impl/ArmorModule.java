package com.luzero.luvoclient.module.impl;

import com.luzero.luvoclient.LuvoClient;
import com.luzero.luvoclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

public class ArmorModule extends Module {
    public ArmorModule() {
        super("armor", "Armor Status", "Shows armor durability", Category.HUD);
    }

    @Override
    public void onHudRender(GuiGraphics graphics, float tickDelta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        float[] pos = LuvoClient.CONFIG.getModulePos(id, 4, 88);
        int x = (int) pos[0];
        int y = (int) pos[1];

        int offset = 0;
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack stack = mc.player.getItemBySlot(slot);
            if (!stack.isEmpty()) {
                graphics.renderItem(stack, x + offset, y);
                // durability text could be added here
                offset += 18;
            }
        }
    }
}
