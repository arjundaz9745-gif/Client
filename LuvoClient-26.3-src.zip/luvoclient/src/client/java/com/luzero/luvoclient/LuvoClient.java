package com.luzero.luvoclient;

import com.luzero.luvoclient.config.LuvoConfig;
import com.luzero.luvoclient.gui.LuvoClickGui;
import com.luzero.luvoclient.keybind.Keybinds;
import com.luzero.luvoclient.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.Minecraft;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LuvoClient implements ClientModInitializer {
    public static final String MOD_ID = "luvoclient";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static LuvoConfig CONFIG;
    public static ModuleManager MODULES;
    public static boolean clickGuiOpen = false;

    @Override
    public void onInitializeClient() {
        LOGGER.info("Initializing Luvo Client...");

        CONFIG = LuvoConfig.load();
        MODULES = new ModuleManager();
        MODULES.init();

        Keybinds.register();

        // Tick for modules + key handling
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            // Open ClickGUI
            if (Keybinds.OPEN_MENU.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new LuvoClickGui());
                }
            }

            MODULES.onTick(client);
        });

        // HUD rendering
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            if (Minecraft.getInstance().options.hideGui) return;
            MODULES.onHudRender(drawContext, tickCounter);
        });

        LOGGER.info("Luvo Client loaded successfully!");
    }
}
