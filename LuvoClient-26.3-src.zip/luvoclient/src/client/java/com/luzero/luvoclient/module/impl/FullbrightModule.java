package com.luzero.luvoclient.module.impl;

import com.luzero.luvoclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

public class FullbrightModule extends Module {
    public FullbrightModule() {
        super("fullbright", "Fullbright", "Makes everything bright (Night Vision style)", Category.RENDER);
    }

    @Override
    public void onTick(Minecraft client) {
        if (client.player == null) return;
        if (isEnabled()) {
            client.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 220, 0, false, false, false));
        } else {
            client.player.removeEffect(MobEffects.NIGHT_VISION);
        }
    }

    @Override
    public void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            mc.player.removeEffect(MobEffects.NIGHT_VISION);
        }
    }
}
