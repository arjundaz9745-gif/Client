package com.luzero.luvoclient.gui;

import com.luzero.luvoclient.LuvoClient;
import com.luzero.luvoclient.module.Module;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

import java.util.List;

/**
 * Simple modern ClickGUI with blur-style dark background.
 * Expand this into full category panels later.
 */
public class LuvoClickGui extends Screen {
    private static final ResourceLocation LOGO = ResourceLocation.fromNamespaceAndPath("luvoclient", "textures/icon/logo.png");

    public LuvoClickGui() {
        super(Component.literal("Luvo Client"));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        // Dark translucent background (simulates blur / Lunar-style dim)
        if (LuvoClient.CONFIG.blurUi) {
            graphics.fill(0, 0, this.width, this.height, 0xCC0A0A12);
        } else {
            this.renderBackground(graphics, mouseX, mouseY, delta);
        }

        // Header
        int panelW = 280;
        int panelH = 320;
        int panelX = (this.width - panelW) / 2;
        int panelY = (this.height - panelH) / 2;

        // Panel background
        graphics.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xEE12121A);
        graphics.fill(panelX, panelY, panelX + panelW, panelY + 28, 0xFF1A1A2E);

        // Logo + Title
        graphics.blit(LOGO, panelX + 8, panelY + 4, 0, 0, 20, 20, 20, 20);
        graphics.drawString(this.font, "LUVO CLIENT", panelX + 34, panelY + 10, 0xFFBB86FC, false);

        // Modules list
        List<Module> mods = LuvoClient.MODULES.getModules();
        int y = panelY + 40;
        for (Module m : mods) {
            boolean enabled = m.isEnabled();
            int color = enabled ? 0xFFBB86FC : 0xFF888888;
            String status = enabled ? "§aON" : "§cOFF";
            graphics.drawString(this.font, m.name + "  " + status, panelX + 16, y, color, false);
            y += 14;
            if (y > panelY + panelH - 20) break;
        }

        // Footer hint
        graphics.drawString(this.font, "Right Shift to close  |  Click modules later", panelX + 12, panelY + panelH - 16, 0xFF666677, false);

        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 344) { // Right Shift
            this.onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
