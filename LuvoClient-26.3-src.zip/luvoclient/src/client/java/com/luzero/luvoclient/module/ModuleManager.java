package com.luzero.luvoclient.module;

import com.luzero.luvoclient.module.impl.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void init() {
        // HUD
        modules.add(new FpsModule());
        modules.add(new CpsModule());
        modules.add(new CoordsModule());
        modules.add(new SpeedModule());
        modules.add(new PingModule());
        modules.add(new MemoryModule());
        modules.add(new ClockModule());
        modules.add(new ArmorModule());

        // Render
        modules.add(new FullbrightModule());
        modules.add(new ZoomModule());
        modules.add(new FreelookModule());
        modules.add(new MotionBlurModule());

        // Misc
        modules.add(new LagFixModule());
    }

    public List<Module> getModules() {
        return modules;
    }

    public Module getById(String id) {
        return modules.stream().filter(m -> m.id.equals(id)).findFirst().orElse(null);
    }

    public void onTick(Minecraft client) {
        for (Module m : modules) {
            if (m.isEnabled()) {
                m.onTick(client);
            }
        }
    }

    public void onHudRender(GuiGraphics graphics, float tickDelta) {
        for (Module m : modules) {
            if (m.isEnabled()) {
                m.onHudRender(graphics, tickDelta);
            }
        }
    }
}
