package com.luzero.luvoclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import net.minecraft.client.gui.Gui;

@Mixin(Gui.class)
public class InGameHudMixin {
    // Reserved for future HUD customisation / vanilla element hiding
}
