package com.luzero.luvoclient.module.impl;

import com.luzero.luvoclient.LuvoClient;
import com.luzero.luvoclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.PlayerInfo;

public class PingModule extends Module {
    public PingModule() {
        super("ping", "Ping", "Shows your latency to the server", Category.HUD);
    }

    @Override
    public void onHudRender(GuiGraphics graphics, float tickDelta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.getConnection() == null) return;

        float[] pos = LuvoClient.CONFIG.getModulePos(id, 4, 52);
        int x = (int) pos[0];
        int y = (int) pos[1];

        PlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        int ping = info != null ? info.getLatency() : -1;

        String text = "Ping: " + (ping >= 0 ? ping + " ms" : "N/A");
        int color = ping < 50 ? 0xFF55FF55 : ping < 100 ? 0xFFFFFF55 : 0xFFFF5555;
        graphics.drawString(mc.font, text, x, y, color, true);
    }
}
