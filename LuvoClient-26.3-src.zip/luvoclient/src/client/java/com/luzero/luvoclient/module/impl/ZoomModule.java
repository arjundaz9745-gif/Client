package com.luzero.luvoclient.module.impl;

import com.luzero.luvoclient.LuvoClient;
import com.luzero.luvoclient.keybind.Keybinds;
import com.luzero.luvoclient.module.Module;
import net.minecraft.client.Minecraft;

public class ZoomModule extends Module {
    private boolean zooming = false;
    private double originalFov = 70;

    public ZoomModule() {
        super("zoom", "Zoom", "Smooth OptiFine-style zoom", Category.RENDER);
    }

    @Override
    public void onTick(Minecraft client) {
        if (!isEnabled() || client.player == null) return;

        boolean keyDown = Keybinds.ZOOM.isDown();
        if (keyDown && !zooming) {
            zooming = true;
            originalFov = client.options.fov().get();
        } else if (!keyDown && zooming) {
            zooming = false;
            client.options.fov().set(originalFov);
        }

        if (zooming) {
            double target = LuvoClient.CONFIG.zoomFov;
            double current = client.options.fov().get();
            // simple smooth
            double next = current + (target - current) * 0.25;
            client.options.fov().set(next);
        }
    }
}
