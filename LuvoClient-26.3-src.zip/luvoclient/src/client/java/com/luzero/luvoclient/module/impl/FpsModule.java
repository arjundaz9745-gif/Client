package com.luzero.luvoclient.module.impl;

import com.luzero.luvoclient.LuvoClient;
import com.luzero.luvoclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public class FpsModule extends Module {
    public FpsModule() {
        super("fps", "FPS", "Shows current frames per second", Category.HUD);
    }

    @Override
    public void onHudRender(GuiGraphics graphics, float tickDelta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        float[] pos = LuvoClient.CONFIG.getModulePos(id, 4, 4);
        int x = (int) pos[0];
        int y = (int) pos[1];

        String text = "FPS: " + mc.getFps();
        graphics.drawString(mc.font, text, x, y, 0xFFAAFFAA, true);
    }
}
