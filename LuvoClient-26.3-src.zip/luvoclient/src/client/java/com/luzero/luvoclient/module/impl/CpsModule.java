package com.luzero.luvoclient.module.impl;

import com.luzero.luvoclient.LuvoClient;
import com.luzero.luvoclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

public class CpsModule extends Module {
    private final List<Long> leftClicks = new ArrayList<>();
    private final List<Long> rightClicks = new ArrayList<>();

    public CpsModule() {
        super("cps", "CPS", "Shows clicks per second", Category.HUD);
    }

    public void onLeftClick() {
        leftClicks.add(System.currentTimeMillis());
    }

    public void onRightClick() {
        rightClicks.add(System.currentTimeMillis());
    }

    private int getCps(List<Long> list) {
        long now = System.currentTimeMillis();
        list.removeIf(t -> now - t > 1000);
        return list.size();
    }

    @Override
    public void onHudRender(GuiGraphics graphics, float tickDelta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        float[] pos = LuvoClient.CONFIG.getModulePos(id, 4, 16);
        int x = (int) pos[0];
        int y = (int) pos[1];

        String text = "CPS: " + getCps(leftClicks) + " | " + getCps(rightClicks);
        graphics.drawString(mc.font, text, x, y, 0xFFAAAAFF, true);
    }
}
