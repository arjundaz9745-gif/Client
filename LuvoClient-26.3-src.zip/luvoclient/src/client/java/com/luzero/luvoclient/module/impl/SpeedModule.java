package com.luzero.luvoclient.module.impl;

import com.luzero.luvoclient.LuvoClient;
import com.luzero.luvoclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

public class SpeedModule extends Module {
    public SpeedModule() {
        super("speed", "Speed", "Shows current movement speed", Category.HUD);
    }

    @Override
    public void onHudRender(GuiGraphics graphics, float tickDelta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        float[] pos = LuvoClient.CONFIG.getModulePos(id, 4, 40);
        int x = (int) pos[0];
        int y = (int) pos[1];

        double dx = mc.player.getX() - mc.player.xOld;
        double dz = mc.player.getZ() - mc.player.zOld;
        double speed = Mth.sqrt((float) (dx * dx + dz * dz)) * 20.0; // blocks per second

        String text = String.format("Speed: %.2f b/s", speed);
        graphics.drawString(mc.font, text, x, y, 0xFFAAFFFF, true);
    }
}
