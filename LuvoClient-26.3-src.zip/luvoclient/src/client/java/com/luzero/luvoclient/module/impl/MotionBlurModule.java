package com.luzero.luvoclient.module.impl;

import com.luzero.luvoclient.LuvoClient;
import com.luzero.luvoclient.module.Module;
import net.minecraft.client.Minecraft;

/**
 * Motion blur is handled primarily in GameRendererMixin.
 * This module just exposes the toggle + strength.
 */
public class MotionBlurModule extends Module {
    public MotionBlurModule() {
        super("motionblur", "Motion Blur", "Adds cinematic motion blur", Category.RENDER);
    }

    @Override
    public void onEnable() {
        LuvoClient.CONFIG.motionBlur = true;
        LuvoClient.CONFIG.save();
    }

    @Override
    public void onDisable() {
        LuvoClient.CONFIG.motionBlur = false;
        LuvoClient.CONFIG.save();
    }
}
