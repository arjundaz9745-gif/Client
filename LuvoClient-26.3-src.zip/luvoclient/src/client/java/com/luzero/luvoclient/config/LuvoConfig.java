package com.luzero.luvoclient.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.luzero.luvoclient.LuvoClient;
import net.fabricmc.loader.api.FabricLoader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class LuvoConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final File CONFIG_FILE = new File(FabricLoader.getInstance().getConfigDir().toFile(), "luvoclient.json");

    // Global
    public boolean blurUi = true;
    public float blurStrength = 8.0f;
    public boolean motionBlur = false;
    public float motionBlurStrength = 0.5f;
    public boolean fullbright = false;
    public boolean zoomEnabled = true;
    public float zoomFov = 30.0f;
    public boolean freelook = false;
    public boolean showLogoOnName = true;
    public boolean lagFix = true; // simple client-side optimisations

    // Module toggles + positions
    public Map<String, Boolean> moduleEnabled = new HashMap<>();
    public Map<String, float[]> modulePos = new HashMap<>(); // [x, y] relative 0-1 or absolute

    public static LuvoConfig load() {
        if (CONFIG_FILE.exists()) {
            try (FileReader reader = new FileReader(CONFIG_FILE)) {
                LuvoConfig cfg = GSON.fromJson(reader, LuvoConfig.class);
                if (cfg != null) {
                    LuvoClient.LOGGER.info("Config loaded.");
                    return cfg;
                }
            } catch (Exception e) {
                LuvoClient.LOGGER.error("Failed to load config", e);
            }
        }
        LuvoConfig cfg = new LuvoConfig();
        cfg.save();
        return cfg;
    }

    public void save() {
        try (FileWriter writer = new FileWriter(CONFIG_FILE)) {
            GSON.toJson(this, writer);
        } catch (IOException e) {
            LuvoClient.LOGGER.error("Failed to save config", e);
        }
    }

    public boolean isModuleEnabled(String id) {
        return moduleEnabled.getOrDefault(id, true);
    }

    public void setModuleEnabled(String id, boolean enabled) {
        moduleEnabled.put(id, enabled);
        save();
    }

    public float[] getModulePos(String id, float defaultX, float defaultY) {
        return modulePos.getOrDefault(id, new float[]{defaultX, defaultY});
    }

    public void setModulePos(String id, float x, float y) {
        modulePos.put(id, new float[]{x, y});
        save();
    }
}
