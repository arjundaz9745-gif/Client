package com.luzero.luvoclient.mixin;

import com.luzero.luvoclient.LuvoClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.PlayerTabOverlay;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Adds the Luvo logo next to the local player's name in the tab list.
 * Expanding this to other players requires a custom payload / presence system.
 */
@Mixin(PlayerTabOverlay.class)
public class PlayerListHudMixin {

    private static final ResourceLocation LOGO = ResourceLocation.fromNamespaceAndPath("luvoclient", "textures/icon/logo.png");

    @Inject(method = "getNameForDisplay", at = @At("RETURN"), cancellable = true)
    private void addLuvoLogo(PlayerInfo entry, CallbackInfoReturnable<Component> cir) {
        if (LuvoClient.CONFIG == null || !LuvoClient.CONFIG.showLogoOnName) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        if (entry.getProfile().getId().equals(mc.player.getUUID())) {
            // Local player → prepend a small marker (real icon rendering needs more complex draw code)
            MutableComponent original = cir.getReturnValue().copy();
            Component withLogo = Component.literal("✦ ").append(original);
            cir.setReturnValue(withLogo);
        }
    }
}
